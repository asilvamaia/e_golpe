:HL["/_next/static/chunks/3c405f4006220905.css","style"]
0:{"buildId":"YDA89MnmA5FrBmT46UWyC","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
