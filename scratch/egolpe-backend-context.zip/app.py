import streamlit as st
import streamlit.components.v1 as components 
import time
import pandas as pd
import json
import os
import re
from datetime import datetime
import asyncio
# Para narração por voz (Acessibilidade)
try:
    from gtts import gTTS
    import tempfile
except ImportError:
    pass

from core import (
    extrair_url, 
    validar_seguranca_url, 
    limpar_dominio, 
    carregar_listas_seguranca,
    checar_dominio_whitelist,
    checar_dominio_blacklist,
    orquestrar_coleta_dados_url,
    analisar_com_ia,        
    analisar_texto_ia,
    checar_cache_analise,
    salvar_feedback,
    desencurtar_link,
    registrar_log,
    checar_senha_vazada,
    analisar_arquivo_ia,
    LOG_FILE
)
from database.db import SessionLocal
from database.models import DatasetItem, Feedback, DomainList

ICON_URL = "https://img.icons8.com/?size=100&id=Q7x2cp7xuVAG&format=png&color=000000"

st.set_page_config(
    page_title="É Golpe?",
    page_icon=ICON_URL,
    layout="centered",
    initial_sidebar_state="collapsed"
)

# --- ESTILIZAÇÃO IOS ---
def configurar_visual_ios():
    st.markdown("""
        <style>
        :root { --ios-bg: #F2F2F7; --ios-card: #FFFFFF; --ios-text: #000000; --ios-button: #007AFF; }
        @media (prefers-color-scheme: dark) { :root { --ios-bg: #000000; --ios-card: #1C1C1E; --ios-text: #FFFFFF; --ios-button: #0A84FF; } }
        .stApp { background-color: var(--ios-bg); font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
        
        /* Layout Limpo */
        header { visibility: hidden; height: 0px; }
        div[data-testid="stHeader"] { display: none !important; }
        .stDeployButton { display: none !important; }
        footer { visibility: hidden; }
        .block-container { padding-top: 2rem; padding-bottom: 5rem; }
        
        /* Inputs */
        div[data-baseweb="input"] { background-color: var(--ios-card) !important; border-radius: 12px; border: 1px solid rgba(0,0,0,0.1); }
        
        /* Botões */
        div.stButton > button[kind="primary"], div[data-testid="stFormSubmitButton"] > button { background-color: var(--ios-button) !important; color: white !important; border-radius: 12px; height: 50px; font-weight: 600; font-size: 16px; border: none; width: 100%; }
        div.stButton > button[kind="secondary"] { background-color: transparent !important; border: 1px solid #ddd !important; color: #333 !important; border-radius: 12px; height: 45px; }
        @media (prefers-color-scheme: dark) { div.stButton > button[kind="secondary"] { color: white !important; border-color: #444 !important; } }
        
        /* Centralizar o botão de submissão do formulário (Auditar Segurança Agora) */
        div[data-testid="stFormSubmitButton"] {
            display: flex !important;
            justify-content: center !important;
            width: 100% !important;
        }
        div[data-testid="stFormSubmitButton"] > button {
            width: 100% !important;
            max-width: 300px !important;
            margin: 0 auto !important;
            display: block !important;
        }
        div.element-container:has(div[data-testid="stFormSubmitButton"]) {
            display: flex !important;
            justify-content: center !important;
            width: 100% !important;
        }
        
        /* Componentes Customizados */
        .status-card { background-color: var(--ios-card); padding: 15px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); margin-bottom: 15px; text-align: center; border: 1px solid rgba(0,0,0,0.1); color: var(--ios-text); }
        .result-box { padding: 25px; border-radius: 16px; text-align: left; margin-bottom: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.08); border: 1px solid rgba(0,0,0,0.05); background-color: var(--ios-card); color: var(--ios-text); }
        .context-box { background-color: rgba(0,0,0,0.03); padding: 10px; border-radius: 8px; margin-bottom: 15px; text-align: center; font-size: 0.9em; color: #666; border: 1px dashed #ccc; }
        .verdict-header { text-align: center; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid #eee; }
        .verdict-title { font-size: 1.8rem; font-weight: 800; letter-spacing: -0.5px; }
        .risk-score { font-size: 1.1rem; color: #666; font-weight: 500; }
        
        /* Cores de Risco */
        .text-safe { color: #28a745; } .text-warning { color: #ffc107; } .text-danger { color: #dc3545; }
        
        /* Ocultando Texto Padrão (Inglês) do File Uploader e Adicionando PT-BR via CSS */
        [data-testid="stFileUploadDropzone"] div div::before {
            content: "Arraste a Cópia de Tela / Print aqui";
            color: var(--ios-text);
            font-size: 14px;
            font-weight: 500;
            display: block;
            margin-bottom: 5px;
        }
        [data-testid="stFileUploadDropzone"] div div span {
            display: none !important;
        }
        [data-testid="stFileUploadDropzone"] div div small {
            display: none !important;
        }
        [data-testid="stFileUploadDropzone"] button {
            background-color: transparent !important;
            border: 1px solid var(--ios-button) !important;
            color: var(--ios-button) !important;
            border-radius: 8px !important;
            padding: 2px 10px !important;
        }
        [data-testid="stFileUploadDropzone"] button::before {
            content: "Procurar Arquivo";
        }
        [data-testid="stFileUploadDropzone"] button span {
            display: none !important;
        }
        
        /* Ajuste do Texto "Limit 200MB" do File Uploader */
        [data-testid="stFileUploadDropzone"]::after {
            content: "Limite: 200MB por arquivo (PNG, JPG, JPEG)";
            color: #888;
            font-size: 12px;
            display: block;
            text-align: center;
            margin-top: -15px;
            margin-bottom: 10px;
        }

        /* Esconde Instruções Padrão */
        [data-testid="InputInstructions"] { display: none !important; }
        div[data-testid="InputInstructions"] { display: none !important; }
        </style>
    """, unsafe_allow_html=True)

    # Injetor Dinâmico de Alto Contraste
    if st.session_state.get('modo_alto_contraste', False):
        st.markdown("""
            <style>
            :root { 
                --ios-bg: #000000 !important; 
                --ios-card: #000000 !important; 
                --ios-text: #FFFF00 !important; 
                --ios-button: #FFFF00 !important; 
            }
            .stApp, .status-card, .result-box, div[data-baseweb="input"] { 
                background-color: #000000 !important;
                color: #FFFF00 !important;
                border: 2px solid #FFFF00 !important;
                font-size: 110% !important;
            }
            .verdict-title, .result-box div { color: #FFFF00 !important; }
            div.stButton > button, div[data-testid="stFormSubmitButton"] > button {
                background-color: #000000 !important;
                color: #FFFF00 !important;
                border: 2px solid #FFFF00 !important;
                font-weight: 900 !important;
            }
            .text-safe, .text-warning, .text-danger { color: #FFFF00 !important; }
            </style>
        """, unsafe_allow_html=True)

configurar_visual_ios()

# --- FUNÇÕES DE UTILS E SEGURANÇA ---
def parse_ia(txt):
    """Extrai veredito e score do texto Markdown gerado pelo Core"""
    ver = re.search(r'\*\*Veredito:?\*\*\s*(\[?.*?\]?)', txt, re.I)
    if ver:
        raw_ver = ver.group(1).replace('[','').replace(']','').strip().upper()
        raw_ver = re.sub(r':\w+', '', raw_ver)
    else:
        raw_ver = "ANÁLISE"
        
    score_match = re.search(r'(?:Score|Nível de Segurança).*?(\d{1,3})', txt, re.I)
    score_val = score_match.group(1) if score_match else "??"
    
    if "SEGURO" in raw_ver or "CONFIÁVEL" in raw_ver: css="text-safe"; i="✅"
    elif "PERIGO" in raw_ver or "GOLPE" in raw_ver or "FAKE" in raw_ver or "ALERTA" in raw_ver or "OFFLINE" in raw_ver: css="text-danger"; i="🚫"
    else: css="text-warning"; i="⚠️"
    
    return raw_ver, score_val, css, i

def check_rate_limit(seconds=3):
    now = time.time()
    last = st.session_state.get('ultima_requisicao', 0)
    if now - last < seconds:
        return False, f"⏳ Aguarde {int(seconds - (now - last))}s..."
    st.session_state['ultima_requisicao'] = now
    return True, ""

def validar_seguranca_input(texto):
    t = texto.lower()
    block = ["ignore previous", "system prompt", "you are a", "act as", "mode developer", "desconsidere as instruções"]
    for b in block: 
        if b in t: return False, "Comando inválido detectado."
    if len(texto) > 4000: return False, "Texto muito longo."
    return True, ""

# --- DIALOGS (POPUPS) ---

@st.dialog("📲 Instalar Aplicativo")
def mostrar_instrucoes_instalacao():
    st.markdown("""
    <div style="text-align: left; font-size: 16px;">
        <p>Adicione à tela inicial para acesso rápido:</p>
        <hr><strong>🍎 iOS:</strong> Compartilhar ⬆️ > <b>"Adicionar à Tela de Início"</b>.
        <hr><strong>🤖 Android:</strong> Menu (⋮) > <b>"Adicionar à tela inicial"</b>.
    </div>""", unsafe_allow_html=True)

@st.dialog("⚖️ Termos de Uso")
def mostrar_disclaimer():
    # USANDO MARKDOWN NATIVO PARA EVITAR QUEBRA DE HTML
    st.markdown("""
    **1. Natureza Informativa**
    
    Este sistema ("IA Contra Fraude") é uma ferramenta de consulta auxiliar baseada em Inteligência Artificial e bancos de dados públicos de segurança cibernética.

    **2. Limitações da Tecnologia**
    
    A detecção de ameaças não é infalível. Podem ocorrer:
    * **Falsos Positivos:** Sites seguros marcados como perigosos.
    * **Falsos Negativos:** Golpes novos (Zero-Day) ainda não catalogados.

    **3. Isenção de Responsabilidade**
    
    Os desenvolvedores e mantenedores deste serviço **não se responsabilizam** por quaisquer danos diretos, indiretos, financeiros, perda de dados ou roubo de identidade resultantes do acesso a links analisados por esta ferramenta.

    **4. Decisão Final**
    
    O acesso a qualquer site é de sua **exclusiva responsabilidade**. Utilize esta ferramenta como uma segunda opinião, mas sempre verifique os canais oficiais.
    """)
    st.markdown("---")
    if st.button("OK, Entendi", use_container_width=True):
        st.rerun()

def is_browser_compatible():
    try:
        ua = ""
        # 1. Tenta obter o User-Agent via API moderna do Streamlit (1.30+)
        if hasattr(st, "context") and hasattr(st.context, "headers"):
            ua = st.context.headers.get("User-Agent", "")
        
        # 2. Fallback para versões anteriores do Streamlit
        if not ua:
            try:
                from streamlit.web.server.websocket_headers import _get_websocket_headers
                headers = _get_websocket_headers()
                if headers:
                    ua = headers.get("User-Agent", "")
            except:
                pass
                
        if not ua:
            return True # Fallback caso não seja possível detectar
            
        ua = ua.lower()
        
        # Dispositivos móveis (celulares e tablets) não suportam extensões de navegador normais
        mobile_indicators = ["iphone", "ipad", "android", "mobi", "mini", "windows phone", "iemobile"]
        if any(ind in ua for ind in mobile_indicators):
            return False
            
        # Verifica se o navegador é baseado em Chromium (Chrome, Edge, Opera, Brave, etc.)
        is_chromium = "chrome" in ua or "chromium" in ua or "edg/" in ua or "opr/" in ua
        
        # Firefox e Safari desktop puro têm suporte/instaladores diferentes para extensões
        is_firefox = "firefox" in ua
        is_safari_pure = "safari" in ua and "chrome" not in ua and "chromium" not in ua and "edg/" not in ua
        
        if is_chromium and not is_firefox and not is_safari_pure:
            return True
            
        return False
    except Exception:
        return True # Fallback seguro em caso de erro interno

def zipar_extensao():
    import io
    import zipfile
    import pathlib
    
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "a", zipfile.ZIP_DEFLATED, False) as zip_file:
        ext_dir = pathlib.Path("browser_extension")
        for file_path in ext_dir.rglob("*"):
            if file_path.is_file():
                # Coloca no zip mantendo a estrutura relativa da pasta 'browser_extension'
                zip_file.write(file_path, file_path.relative_to(ext_dir.parent))
    return zip_buffer.getvalue()

@st.dialog("🧩 Instalar Extensão de Navegador")
def mostrar_instrucoes_extensao():
    st.markdown("""
    A extensão do **IA Contra Fraude** protege sua navegação de forma automática e integrada, analisando os sites que você acessa em tempo real!
    
    Como os navegadores (Chrome, Edge, Brave, etc.) exigem a publicação oficial nas lojas para instalações automatizadas de um clique, você pode usar a nossa extensão de forma totalmente gratuita e segura ativando o **Modo de Desenvolvedor** do seu navegador. 
    
    Siga estes passos rápidos e simples:
    
    ---
    ### 1️⃣ Baixe os Arquivos da Extensão
    Clique no botão abaixo para baixar a extensão oficial compactada (formato ZIP):
    """)
    
    try:
        conteudo_zip = zipar_extensao()
        st.download_button(
            label="⬇️ Baixar Extensão do IA Contra Fraude (.ZIP)",
            data=conteudo_zip,
            file_name="ia_contra_fraude_extensao.zip",
            mime="application/zip",
            use_container_width=True,
            type="primary"
        )
    except Exception as e:
        st.error(f"Erro ao gerar pacote de download da extensão: {e}")
        
    st.markdown("""
    ---
    ### 2️⃣ Como instalar no seu Navegador:
    
    **Compatível com Google Chrome, Microsoft Edge, Brave, Opera ou qualquer navegador baseado em Chromium:**
    
    1. **Extraia o arquivo ZIP** que você acabou de baixar no seu computador (clique com o botão direito sobre o arquivo `ia_contra_fraude_extensao.zip` e escolha a opção *Extrair Tudo...*). Isso gerará uma pasta chamada `browser_extension`.
    2. No seu navegador, abra a página de extensões digitando um dos endereços abaixo na barra de busca:
       * **Google Chrome:** `chrome://extensions/`
       * **Microsoft Edge:** `edge://extensions/`
       * **Brave Browser:** `brave://extensions/`
    3. No canto superior direito, **ative a opção "Modo do desenvolvedor"** (ou *Developer mode* ⚙️).
    4. No canto superior esquerdo, clique no botão **"Carregar sem compactação"** (ou *Load unpacked* 📁).
    5. Selecione a pasta `browser_extension` que você extraiu no Passo 1.
    
    ✨ **Pronto!** A extensão está ativa. Agora você pode clicar no ícone do **IA Contra Fraude** na barra de ferramentas do seu navegador sempre que quiser auditar a segurança de qualquer site aberto instantaneamente!
    """)

# --- SESSION STATE ---
if 'texto_para_analisar' not in st.session_state: st.session_state['texto_para_analisar'] = ""
if 'ultima_requisicao' not in st.session_state: st.session_state['ultima_requisicao'] = 0
if 'ultimo_resultado_ia' not in st.session_state: st.session_state['ultimo_resultado_ia'] = None
if 'dados_tecnicos_cache' not in st.session_state: st.session_state['dados_tecnicos_cache'] = None
if 'feedback_enviado' not in st.session_state: st.session_state['feedback_enviado'] = False
if 'modo_admin' not in st.session_state: st.session_state['modo_admin'] = False
if 'admin_autenticado' not in st.session_state: st.session_state['admin_autenticado'] = False
if 'processing' not in st.session_state: st.session_state['processing'] = False

# Acessibilidade
if 'modo_alto_contraste' not in st.session_state: st.session_state['modo_alto_contraste'] = False
if 'narracao_ativa' not in st.session_state: st.session_state['narracao_ativa'] = False
if 'ultimo_audio_falado' not in st.session_state: st.session_state['ultimo_audio_falado'] = ""

# --- LÓGICA DE LOGIN ADMIN ---
MAGIC_WORD = os.getenv("MAGIC_WORD", "Ck90t&c@@") # Fallback se não setado
ADMIN_PASS_HASH = os.getenv("ADMIN_PASS_HASH")

# Usando bcrypt para validar senha, caso configurada
import bcrypt
def verificar_senha(senha_raw, senha_hash):
    if not senha_hash: return False
    try:
        return bcrypt.checkpw(senha_raw.encode('utf-8'), senha_hash.encode('utf-8'))
    except:
        return False


def submeter_consulta():
    nova_entrada = st.session_state.widget_input
    nova_imagem = st.session_state.widget_image
    nova_senha = st.session_state.widget_password
    
    if nova_entrada.strip() == MAGIC_WORD:
        st.session_state['modo_admin'] = True
        st.session_state.widget_input = ""
        st.session_state.widget_image = None
        st.session_state.widget_password = ""
        return

    if not nova_entrada and not nova_imagem and not nova_senha:
        st.toast("Preencha algum campo ou envie uma imagem.", icon="⚠️")
        return

    safe, msg_erro = validar_seguranca_input(nova_entrada)
    if nova_entrada and not safe:
        st.toast(msg_erro, icon="❌")
        return

    ok, msg_rate = check_rate_limit()
    if not ok:
        st.toast(msg_rate, icon="⏳")
        return
    
    st.session_state['feedback_enviado'] = False
    st.session_state['ultimo_resultado_ia'] = None
    st.session_state['dados_tecnicos_cache'] = None
    st.session_state['texto_para_analisar'] = nova_entrada
    st.session_state['imagem_para_analisar'] = nova_imagem
    st.session_state['senha_para_analisar'] = nova_senha
    st.session_state.widget_input = ""
    # st.session_state.widget_image is cleared automatically by Streamlit
    st.session_state.widget_password = ""
    st.session_state['processing'] = True

def realizar_login_admin():
    senha_digitada = st.session_state.senha_admin
    admin_hash_limpo = ADMIN_PASS_HASH.strip() if ADMIN_PASS_HASH else None
    
    # Se ADMIN_PASS_HASH não existir no .env ou for vazio, usa o fallback seguro
    fallback = os.getenv("ADMIN_PASS_FALLBACK")
    fallback = fallback.strip() if fallback else ""

    if admin_hash_limpo and verificar_senha(senha_digitada, admin_hash_limpo):
        st.session_state['admin_autenticado'] = True
        st.session_state['login_error'] = None
    elif not admin_hash_limpo and senha_digitada == fallback:
        # FALLBACK temporário para não quebrar o app se o bcrypt não estiver configurado
        st.session_state['admin_autenticado'] = True
        st.session_state['login_error'] = None
    else:
        st.session_state['login_error'] = "Senha incorreta."

def sair_admin():
    st.session_state['modo_admin'] = False
    st.session_state['admin_autenticado'] = False

def carregar_arquivo_lista(list_type):
    db = SessionLocal()
    try:
        records = db.query(DomainList.domain).filter(DomainList.list_type == list_type).all()
        return "\n".join([r[0] for r in records])
    finally:
        db.close()

def salvar_arquivo_lista(list_type, conteudo):
    db = SessionLocal()
    try:
        domains = [d.strip().lower() for d in conteudo.split("\n") if d.strip()]
        db.query(DomainList).filter(DomainList.list_type == list_type).delete()
        
        batch = [{"domain": d, "list_type": list_type} for d in set(domains)]
        if batch:
            db.bulk_insert_mappings(DomainList, batch)
        db.commit()
        st.toast(f"Lista {list_type} salva com sucesso!", icon="✅")
    except Exception as e:
        db.rollback()
        st.error(f"Erro ao salvar: {e}")
    finally:
        db.close()

def processar_feedback_wrapper(tipo):
    if st.session_state.get('ultimo_resultado_ia'):
        input_usado = st.session_state.get('texto_para_analisar') or "IMAGEM/SENHA_OCULTA"
        salvar_feedback(input_usado, st.session_state['ultimo_resultado_ia'], tipo)
        st.session_state['feedback_enviado'] = True
        st.toast("Obrigado pelo feedback!", icon="🙏")

def get_remote_ip():
    try:
        if hasattr(st, "context") and hasattr(st.context, "headers"):
            headers = st.context.headers
            return headers.get("X-Forwarded-For", "127.0.0.1").split(',')[0]
        return "127.0.0.1"
    except: return "127.0.0.1"

# --- INJEÇÃO DE JS ---
components.html(f"""<script>
    function injectAppleIcon() {{ var head = window.parent.document.getElementsByTagName('head')[0]; var link = window.parent.document.querySelector("link[rel='apple-touch-icon']"); if (!link) {{ link = window.parent.document.createElement('link'); link.rel = 'apple-touch-icon'; head.appendChild(link); }} link.href = '{ICON_URL}'; }}
    function manageInstallButton() {{ const parentWindow = window.parent || window; const isStandalone = parentWindow.matchMedia('(display-mode: standalone)').matches || parentWindow.navigator.standalone === true; if (isStandalone) {{ const doc = parentWindow.document || document; const buttons = doc.getElementsByTagName('button'); for (let btn of buttons) {{ if (btn.innerText.includes('Instalar App')) {{ btn.style.display = 'none'; if (btn.parentElement && btn.parentElement.classList.contains('stButton')) {{ btn.parentElement.style.display = 'none'; }} }} }} }} }}
    
    injectAppleIcon(); 
    setInterval(manageInstallButton, 1000);
    </script>""", height=0)

# --- INTERFACE PRINCIPAL ---

if st.session_state['modo_admin']:
    if not st.session_state['admin_autenticado']:
        st.title("🔒 Acesso Restrito")
        st.text_input("Senha de Administrador:", type="password", key="senha_admin", on_change=realizar_login_admin)
        if st.session_state.get('login_error'):
            st.error(st.session_state['login_error'])
        if st.button("Voltar"): sair_admin()
    else:
        st.title("⚙️ Painel de Controle")
        if st.session_state.get('success_message'):
            st.success(st.session_state['success_message'])
            st.session_state['success_message'] = None
        if st.button("Sair"): sair_admin()
        
        tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(["📊 Dashboard", "🕵️ Histórico", "✅ Whitelist", "🚫 Blacklist", "📜 Logs", "💾 Backups"])
        
        with tab1:
            st.subheader("Analytics")
            db = SessionLocal()
            try:
                # Analytics Dataset
                df = pd.read_sql(db.query(DatasetItem).statement, db.bind)
                if not df.empty:
                    df['data'] = pd.to_datetime(df['timestamp']).dt.date
                    col1, col2 = st.columns(2)
                    col1.metric("Consultas Totais", len(df))
                    st.bar_chart(df.groupby('data').size())
                    
                    st.markdown("---")
                    
                    c_btn1, c_btn2 = st.columns(2)
                    with c_btn1:
                        if st.button("📄 Gerar Relatório (PDF)", use_container_width=True):
                            from fpdf import FPDF
                            import tempfile
                            class PDF(FPDF):
                                def header(self):
                                    self.set_font('helvetica', 'B', 15)
                                    self.cell(0, 10, 'IA Contra Fraude - Relatório de Segurança', border=False, align='C')
                                    self.ln(20)
                            pdf = PDF()
                            pdf.add_page()
                            pdf.set_font('helvetica', '', 12)
                            pdf.cell(0, 10, f"Data de geração: {datetime.now().strftime('%d/%m/%Y %H:%M')}", ln=True)
                            pdf.cell(0, 10, f"Total de consultas analisadas: {len(df)}", ln=True)
                            
                            # Contar golpes vs seguros
                            seguros = sum(1 for _, row in df.iterrows() if "SEGURO" in str(row['analise_modelo']))
                            golpes = sum(1 for _, row in df.iterrows() if "GOLPE" in str(row['analise_modelo']) or "PERIGO" in str(row['analise_modelo']))
                            pdf.cell(0, 10, f"Sites/Mensagens Seguras: {seguros}", ln=True)
                            pdf.cell(0, 10, f"Ameaças Detectadas: {golpes}", ln=True)
                            
                            with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as tmp:
                                pdf.output(tmp.name)
                                with open(tmp.name, "rb") as pdf_file:
                                    st.download_button("⬇️ Baixar PDF", data=pdf_file, file_name=f"relatorio_ia_contra_fraude_{datetime.now().strftime('%Y%m%d')}.pdf", mime="application/pdf")
                    
                    with c_btn2:
                        if st.button("🧠 Preparar Retreinamento", use_container_width=True, type="primary"):
                            with st.spinner("Compilando feedbacks negativos para a IA..."):
                                import subprocess
                                import sys
                                try:
                                    resultado = subprocess.run([sys.executable, "scripts/preparar_finetune.py"], capture_output=True, text=True)
                                    if resultado.returncode == 0:
                                        st.success("Dataset de retreinamento gerado com sucesso!")
                                        st.code(resultado.stdout)
                                    else:
                                        st.error(f"Erro ao gerar dataset: {resultado.stderr}")
                                except Exception as e:
                                    st.error(f"Erro ao executar script: {e}")

                else: 
                    st.info("Sem dados de consultas.")

                # Analytics Feedbacks
                df_f = pd.read_sql(db.query(Feedback).statement, db.bind)
                if not df_f.empty:
                    st.subheader("Feedbacks")
                    st.bar_chart(df_f['avaliacao'].value_counts())
            except Exception as e:
                st.error(f"Erro no Analytics: {e}")
            finally:
                db.close()

        with tab2:
            st.subheader("Histórico de Consultas")
            db = SessionLocal()
            try:
                query = db.query(DatasetItem).order_by(DatasetItem.timestamp.desc()).limit(100).all()
                if query:
                    table_data = []
                    for item in query:
                        meta = item.metadados or {}
                        origem = meta.get('origem', meta.get('ip', 'Desconhecido'))
                        dados_tec = item.dados_tecnicos or {}
                        entrada = dados_tec.get('input') or dados_tec.get('url_final') or dados_tec.get('texto_puro') or "N/A"
                        raw_veredito = item.analise_modelo or ""
                        
                        veredito_limpo = "Indefinido"
                        if "SEGURO" in raw_veredito: veredito_limpo = "✅ SEGURO"
                        elif "PERIGO" in raw_veredito or "GOLPE" in raw_veredito: veredito_limpo = "🚨 GOLPE"
                        elif "ALERTA" in raw_veredito: veredito_limpo = "⚠️ ALERTA"
                        
                        table_data.append({
                            "Data": pd.to_datetime(item.timestamp).strftime('%d/%m %H:%M'),
                            "Origem": origem,
                            "Consulta": str(entrada)[:60],
                            "Status": veredito_limpo
                        })
                    
                    df_hist = pd.DataFrame(table_data)
                    st.dataframe(df_hist, width=1000, hide_index=True)
                else:
                    st.info("Nenhum histórico disponível.")
            except Exception as e:
                st.error(f"Erro histórico: {e}")
            finally:
                db.close()

        with tab3:
            st.subheader("🛡️ Domínios Verificados (Whitelist)")
            st.markdown("Gerencie a lista de sites oficiais e confiáveis que são pulados pelas verificações de risco.")
            
            # Adicionar Novo / Importar
            c_wl1, c_wl2 = st.columns(2)
            with c_wl1:
                with st.expander("➕ Adicionar Novo Domínio Seguro", expanded=False):
                    with st.form("form_add_wl"):
                        new_wl = st.text_input("Domínio (ex: banco.com.br):", placeholder="exemplo.com.br").strip().lower()
                        if st.form_submit_button("Adicionar à Whitelist", type="primary"):
                            if not new_wl:
                                st.warning("Digite um domínio válido.")
                            else:
                                db = SessionLocal()
                                try:
                                    # Check if exists
                                    existing = db.query(DomainList).filter(DomainList.domain == new_wl).first()
                                    if existing:
                                        st.warning(f"O domínio {new_wl} já está cadastrado como {existing.list_type}!")
                                    else:
                                        db.add(DomainList(domain=new_wl, list_type="whitelist"))
                                        db.commit()
                                        st.session_state['success_message'] = f"Domínio {new_wl} adicionado com sucesso!"
                                        st.rerun()
                                except Exception as e:
                                    db.rollback()
                                    st.error(f"Erro ao salvar: {e}")
                                finally:
                                    db.close()

            with c_wl2:
                with st.expander("📂 Importação em Massa (.TXT)", expanded=False):
                    uploaded_file_wl = st.file_uploader("Selecione um arquivo de texto com 1 domínio por linha:", type=["txt"], key="bulk_upload_wl")
                    if uploaded_file_wl is not None:
                        if st.button("Confirmar Importação", type="primary", use_container_width=True, key="btn_confirm_wl"):
                            content = uploaded_file_wl.getvalue().decode("utf-8")
                            domains = [d.strip().lower() for d in content.split("\n") if d.strip()]
                            if domains:
                                with st.spinner(f"Importando {len(domains)} domínios..."):
                                    db = SessionLocal()
                                    try:
                                        # Evitar duplicados no banco globalmente (coluna domain possui UNIQUE constraint)
                                        existing_records = db.query(DomainList.domain).all()
                                        existing_set = set(r[0].lower().strip() for r in existing_records)
                                        
                                        novos_dominios = [d for d in set(domains) if d not in existing_set]
                                        
                                        batch = [{"domain": d, "list_type": "whitelist"} for d in novos_dominios]
                                        if batch:
                                            # Insere em lotes de 10.000 para segurança e eficiência
                                            tamanho_lote = 10000
                                            for i in range(0, len(batch), tamanho_lote):
                                                db.bulk_insert_mappings(DomainList, batch[i:i+tamanho_lote])
                                            db.commit()
                                            st.session_state['success_message'] = f"Sucesso! {len(novos_dominios)} novos domínios adicionados."
                                        else:
                                            st.session_state['success_message'] = "Todos os domínios enviados já existem no banco de dados."
                                        st.rerun()
                                    except Exception as e:
                                        db.rollback()
                                        st.error(f"Erro na importação: {e}")
                                    finally:
                                        db.close()

            # Caixa de busca
            search_wl = st.text_input("🔍 Pesquisar na Whitelist:", placeholder="Digite o domínio para pesquisar...").strip().lower()
            
            db = SessionLocal()
            try:
                # Se houver busca
                if search_wl:
                    records = db.query(DomainList).filter(
                        DomainList.list_type == "whitelist",
                        DomainList.domain.like(f"%{search_wl}%")
                    ).all()
                    
                    if records:
                        st.write(f"🔍 Resultados da busca ({len(records)}):")
                        for item in records:
                            c1, c2 = st.columns([5, 1])
                            c1.code(item.domain)
                            if c2.button("Excluir", key=f"del_wl_search_{item.id}", type="secondary"):
                                db.delete(item)
                                db.commit()
                                st.success(f"{item.domain} removido!")
                                st.rerun()
                    else:
                        st.info("Nenhum domínio correspondente encontrado.")
                else:
                    # Paginação de 15 em 15
                    total_wl = db.query(DomainList).filter(DomainList.list_type == "whitelist").count()
                    st.write(f"📋 Total cadastrado: **{total_wl}** domínios")
                    
                    if total_wl > 0:
                        itens_por_pagina = 15
                        total_paginas = max(1, -(-total_wl // itens_por_pagina)) # Teto da divisão
                        
                        # Guardar a página atual na session state
                        if 'page_wl' not in st.session_state:
                            st.session_state['page_wl'] = 1
                            
                        # Controles de página
                        col_p1, col_p2, col_p3 = st.columns([1, 4, 1])
                        with col_p1:
                            if st.button("⬅️", key="prev_wl_page", disabled=st.session_state['page_wl'] == 1):
                                st.session_state['page_wl'] -= 1
                                st.rerun()
                        with col_p2:
                            st.markdown(f"<div style='text-align: center;'>Página <b>{st.session_state['page_wl']}</b> de <b>{total_paginas}</b></div>", unsafe_allow_html=True)
                        with col_p3:
                            if st.button("➡️", key="next_wl_page", disabled=st.session_state['page_wl'] == total_paginas):
                                st.session_state['page_wl'] += 1
                                st.rerun()
                                
                        offset = (st.session_state['page_wl'] - 1) * itens_por_pagina
                        records = db.query(DomainList).filter(DomainList.list_type == "whitelist").order_by(DomainList.id.desc()).offset(offset).limit(itens_por_pagina).all()
                        
                        # Exibe a lista
                        for item in records:
                            c1, c2 = st.columns([5, 1])
                            c1.code(item.domain)
                            if c2.button("Excluir", key=f"del_wl_{item.id}", type="secondary"):
                                db.delete(item)
                                db.commit()
                                st.success(f"{item.domain} removido!")
                                st.rerun()
                    else:
                        st.info("A whitelist está vazia.")
            except Exception as e:
                st.error(f"Erro ao carregar dados: {e}")
            finally:
                db.close()

        with tab4:
            st.subheader("🚫 Domínios Bloqueados (Blacklist)")
            st.markdown("Gerencie domínios identificados ativamente como perigosos ou tentativas de golpe.")
            
            # Adicionar Novo
            c_add1, c_add2 = st.columns(2)
            with c_add1:
                with st.expander("➕ Adicionar Novo Domínio Perigoso", expanded=False):
                    with st.form("form_add_bl"):
                        new_bl = st.text_input("Domínio (ex: site-golpe.com):", placeholder="exemplo.com").strip().lower()
                        if st.form_submit_button("Adicionar à Blacklist", type="primary"):
                            if not new_bl:
                                st.warning("Digite um domínio válido.")
                            else:
                                db = SessionLocal()
                                try:
                                    existing = db.query(DomainList).filter(DomainList.domain == new_bl).first()
                                    if existing:
                                        st.warning(f"O domínio {new_bl} já está cadastrado como {existing.list_type}!")
                                    else:
                                        db.add(DomainList(domain=new_bl, list_type="blacklist"))
                                        db.commit()
                                        st.session_state['success_message'] = f"Domínio {new_bl} adicionado com sucesso!"
                                        st.rerun()
                                except Exception as e:
                                    db.rollback()
                                    st.error(f"Erro ao salvar: {e}")
                                finally:
                                    db.close()
            with c_add2:
                with st.expander("📂 Importação em Massa (.TXT)", expanded=False):
                    uploaded_file = st.file_uploader("Selecione um arquivo de texto com 1 domínio por linha:", type=["txt"], key="bulk_upload_bl")
                    if uploaded_file is not None:
                        if st.button("Confirmar Importação", type="primary", use_container_width=True):
                            content = uploaded_file.getvalue().decode("utf-8")
                            domains = [d.strip().lower() for d in content.split("\n") if d.strip()]
                            if domains:
                                with st.spinner(f"Importando {len(domains)} domínios..."):
                                    db = SessionLocal()
                                    try:
                                        # Evitar duplicados no banco globalmente (coluna domain possui UNIQUE constraint)
                                        existing_records = db.query(DomainList.domain).all()
                                        existing_set = set(r[0].lower().strip() for r in existing_records)
                                        
                                        novos_dominios = [d for d in set(domains) if d not in existing_set]
                                        
                                        batch = [{"domain": d, "list_type": "blacklist"} for d in novos_dominios]
                                        if batch:
                                            # Insere em lotes de 10.000 para segurança e eficiência
                                            tamanho_lote = 10000
                                            for i in range(0, len(batch), tamanho_lote):
                                                db.bulk_insert_mappings(DomainList, batch[i:i+tamanho_lote])
                                            db.commit()
                                            st.session_state['success_message'] = f"Sucesso! {len(novos_dominios)} novos domínios adicionados."
                                        else:
                                            st.session_state['success_message'] = "Todos os domínios enviados já existem no banco de dados."
                                        st.rerun()
                                    except Exception as e:
                                        db.rollback()
                                        st.error(f"Erro na importação: {e}")
                                    finally:
                                        db.close()

            # Caixa de busca
            search_bl = st.text_input("🔍 Pesquisar na Blacklist:", placeholder="Digite o domínio para pesquisar...").strip().lower()
            
            db = SessionLocal()
            try:
                if search_bl:
                    # Busca indexada rápida por substring
                    records = db.query(DomainList).filter(
                        DomainList.list_type == "blacklist",
                        DomainList.domain.like(f"%{search_bl}%")
                    ).limit(50).all() # Limite de 50 para evitar travamentos de rendering se a busca for muito genérica
                    
                    if records:
                        st.write(f"🔍 Resultados da busca (mostrando até 50):")
                        for item in records:
                            c1, c2 = st.columns([5, 1])
                            c1.code(item.domain)
                            if c2.button("Excluir", key=f"del_bl_search_{item.id}", type="secondary"):
                                db.delete(item)
                                db.commit()
                                st.success(f"{item.domain} removido!")
                                st.rerun()
                    else:
                        st.info("Nenhum domínio correspondente encontrado.")
                else:
                    # Paginação de 15 em 15
                    total_bl = db.query(DomainList).filter(DomainList.list_type == "blacklist").count()
                    st.write(f"📋 Total cadastrado: **{total_bl}** domínios")
                    
                    if total_bl > 0:
                        itens_por_pagina = 15
                        total_paginas = max(1, -(-total_bl // itens_por_pagina))
                        
                        if 'page_bl' not in st.session_state:
                            st.session_state['page_bl'] = 1
                            
                        col_p1, col_p2, col_p3 = st.columns([1, 4, 1])
                        with col_p1:
                            if st.button("⬅️", key="prev_bl_page", disabled=st.session_state['page_bl'] == 1):
                                st.session_state['page_bl'] -= 1
                                st.rerun()
                        with col_p2:
                            st.markdown(f"<div style='text-align: center;'>Página <b>{st.session_state['page_bl']}</b> de <b>{total_paginas}</b></div>", unsafe_allow_html=True)
                        with col_p3:
                            if st.button("➡️", key="next_bl_page", disabled=st.session_state['page_bl'] == total_paginas):
                                st.session_state['page_bl'] += 1
                                st.rerun()
                                
                        offset = (st.session_state['page_bl'] - 1) * itens_por_pagina
                        records = db.query(DomainList).filter(DomainList.list_type == "blacklist").order_by(DomainList.id.desc()).offset(offset).limit(itens_por_pagina).all()
                        
                        for item in records:
                            c1, c2 = st.columns([5, 1])
                            c1.code(item.domain)
                            if c2.button("Excluir", key=f"del_bl_{item.id}", type="secondary"):
                                db.delete(item)
                                db.commit()
                                st.success(f"{item.domain} removido!")
                                st.rerun()
                    else:
                        st.info("A blacklist está vazia.")
            except Exception as e:
                st.error(f"Erro ao carregar dados: {e}")
            finally:
                db.close()

        with tab5:
            st.subheader("Logs")
            if LOG_FILE.exists():
                with open(LOG_FILE, 'r', encoding='utf-8', errors='ignore') as f: st.code("".join(f.readlines()[-50:]))
            else: st.info("Vazio.")

        with tab6:
            st.subheader("Bkp do Banco de Dados")
            st.write("Baixe todas as tabelas do banco de dados (SQLite) para segurança.")
            if st.button("Gerar Arquivo de Backup (.ZIP)"):
                import io
                import zipfile
                db = SessionLocal()
                try:
                    with st.spinner("Extraindo banco de dados..."):
                        zip_buffer = io.BytesIO()
                        with zipfile.ZipFile(zip_buffer, "a", zipfile.ZIP_DEFLATED, False) as zip_file:
                            # Tabela Analises (Dataset)
                            df_hist = pd.read_sql(db.query(DatasetItem).statement, db.bind)
                            zip_file.writestr("historico_analises.csv", df_hist.to_csv(index=False))
                            
                            # Tabela Feedbacks
                            df_feed = pd.read_sql(db.query(Feedback).statement, db.bind)
                            zip_file.writestr("feedbacks.csv", df_feed.to_csv(index=False))
                            
                            # Tabela Listas
                            df_list = pd.read_sql(db.query(DomainList).statement, db.bind)
                            zip_file.writestr("listas_brancas_negras.csv", df_list.to_csv(index=False))

                        st.success("Backup gerado com sucesso!")
                        st.download_button(
                            label="⬇️ Baixar Backup Agora",
                            data=zip_buffer.getvalue(),
                            file_name=f"egolpe_backup_{datetime.now().strftime('%Y%m%d_%H%M')}.zip",
                            mime="application/zip"
                        )
                except Exception as e:
                    st.error(f"Erro ao gerar backup: {e}")
                finally:
                    db.close()

else:
    st.markdown("<h1 style='text-align: center; margin-bottom: 0px;'>🛡️ É Golpe?</h1>", unsafe_allow_html=True)
    st.markdown("<h3 style='text-align: center; color: gray; margin-top: -10px; font-size: 1rem;'>IA contra Fraudes Digitais</h3>", unsafe_allow_html=True)

    with st.form(key='form_verificacao'):
        locked = st.session_state['processing']
        
        st.markdown("### 🔍 O que você quer analisar?")
        
        tab_texto, tab_imagem, tab_senha = st.tabs(["📝 Texto / Link / Chave PIX", "📸 Enviar Print da Tela", "🔒 Teste de Senha Vazada"])
        
        with tab_texto:
            st.info("💡 **Dica PIX:** A IA não acha o dono da chave aleatória, mas lê a mensagem inteira pra achar gatilhos de golpe!")
            st.text_area("Cole a mensagem suspeita, o site ou a chave PIX:", height=100, placeholder="Exemplo: 'Mãe me manda um pix pra essa chave nova...' ou 'http://site-promocao.com'", key="widget_input", disabled=locked)
            
        with tab_imagem:
            st.caption("Faça o upload de uma captura de tela (Print) ou Arquivo PDF para a Inteligência Artificial ler e analisar sentenças/petições.")
            st.file_uploader("Selecione a Imagem ou PDF", type=['png', 'jpg', 'jpeg', 'pdf'], key="widget_image", disabled=locked, label_visibility="collapsed")
            
        with tab_senha:
            st.caption("Verifique se a sua senha já apareceu em grandes bases de hackers na Deep Web.")
            st.text_input("Digite a Senha (não será salva ou logada):", type="password", key="widget_password", disabled=locked)
            
        st.markdown("<br>", unsafe_allow_html=True)
        st.form_submit_button("Auditar Segurança Agora", type="primary", on_click=submeter_consulta, disabled=locked)

    texto_analise = st.session_state['texto_para_analisar']
    imagem_analise = st.session_state.get('imagem_para_analisar')
    senha_analise = st.session_state.get('senha_para_analisar')

    if (texto_analise or imagem_analise or senha_analise) and st.session_state['processing']:
        url_check = extrair_url(texto_analise)
        status_box = st.empty()
        status_box.markdown(f"<div class='status-card'>🔎 Iniciando auditoria...</div>", unsafe_allow_html=True)
        
        user_ip = get_remote_ip()
        meta_web = {"origem": f"Web ({user_ip})"}
        resultado_final = ""
        dados_tecnicos_capturados = None

        try:
            if senha_analise:
                status_box.markdown(f"<div class='status-card'>🔎 Consultando banco de dados de vazamentos...</div>", unsafe_allow_html=True)
                vazada = asyncio.run(checar_senha_vazada(senha_analise))
                
                if vazada:
                    resultado_final = f"""
                    **Veredito:** :red[**VAZADA (PERIGO)**]

                    🛡️ **Nível de Segurança:** 0/100

                    **Análise:**
                    Esta senha foi encontrada em vazamentos de dados públicos (Data Breaches). 
                    
                    **Ação:**
                    - 🚫 **NUNCA** use essa senha. Mude imediatamente caso a utilize em algum serviço.
                    """
                else:
                    resultado_final = f"""
                    **Veredito:** :green[**SEGURA**]

                    🛡️ **Nível de Segurança:** 100/100

                    **Análise:**
                    Esta senha **não** foi encontrada em nenhum banco público de vazamentos conhecidos até o momento.
                    """
                    
            elif imagem_analise:
                status_box.markdown(f"<div class='status-card'>👁️ IA extraindo texto e metadados analíticos do arquivo...</div>", unsafe_allow_html=True)
                img_bytes = imagem_analise.getvalue()
                mime_type = imagem_analise.type
                resultado_final = asyncio.run(analisar_arquivo_ia(img_bytes, mime_type, origem="streamlit", metadados=meta_web))

            elif texto_analise:
                if url_check:
                    status_box.markdown(f"<div class='status-card'>🌐 Auditando domínio...</div>", unsafe_allow_html=True)
                    
                    if not url_check.startswith("http"): url_temp = "http://" + url_check
                    else: url_temp = url_check
                    url_final, foi_desencurtado = desencurtar_link(url_temp)
                    
                    if foi_desencurtado:
                        st.toast(f"Redirecionamento: {limpar_dominio(url_final)}", icon="➡️")

                    domain_clean = limpar_dominio(url_final)
                    
                    # Check de Blacklist
                    eh_blacklist = checar_dominio_blacklist(domain_clean)
                    
                    if eh_blacklist:
                        status_box.empty()
                        resultado_final = f"""
                        **Veredito:** :red[**GOLPE**]

                        🛡️ **Nível de Segurança:** 0/100

                        **Análise:**
                        Este domínio ({domain_clean}) foi identificado no banco de dados de ameaças ativas.
                        
                        **Ação:**
                        - 🚫 NÃO ACESSE este site.
                        - Bloqueie o remetente.
                        """
                    else:
                        seguro_tecnico, motivo, url_validada = validar_seguranca_url(url_final)
                        
                        if not seguro_tecnico and "DNS_FAIL" in motivo:
                            status_box.empty()
                            resultado_final = f"""
                            **Veredito:** :orange[**SITE OFFLINE**]

                            🛡️ **Nível de Segurança:** 0/100

                            **Análise:**
                            Não conseguimos conectar ao site **{domain_clean}**.
                            
                            **Por que isso acontece?**
                            1. O site pode ter sido **derrubado por denúncias de fraude**.
                            2. O endereço pode não existir.
                            3. O servidor está desligado.

                            **Ação Recomendada:**
                            ⚠️ **Tenha cautela redobrada.** Se você recebeu este link com promessas de ganhos ou cobranças urgentes, é muito provável que seja um golpe que já foi neutralizado.
                            """
                        
                        elif not seguro_tecnico:
                            status_box.empty()
                            st.error(f"🚫 **Bloqueio de Segurança:** {motivo}")
                            resultado_final = None
                        
                        else:
                            status_box.markdown(f"<div class='status-card'>🤖 IA verificando padrões...</div>", unsafe_allow_html=True)
                            url_final = url_validada
                            domain_clean = limpar_dominio(url_final)
                            
                            eh_confiavel = checar_dominio_whitelist(domain_clean)
                            
                            if eh_confiavel:
                                resultado_final = f"**Veredito:** :green[**SEGURO**]\n\n**Score:** 100/100\n\n✅ **SITE OFICIAL:** {domain_clean}\nEste é um domínio verificado."
                            else:
                                cache_analise, cache_dados = checar_cache_analise(url_final)
                                if cache_analise:
                                    dados_tecnicos_capturados = cache_dados
                                    resultado_final = cache_analise + "\n\n*(⚡ Resultado obtido do Cache)*"
                                else:
                                    dados = asyncio.run(orquestrar_coleta_dados_url(url_final))
                                    dados_tecnicos_capturados = dados 
                                    resultado_final = asyncio.run(analisar_com_ia(url_final, dados, origem="streamlit", metadados=meta_web))
                else:
                    status_box.markdown(f"<div class='status-card'>🧠 IA lendo mensagem...</div>", unsafe_allow_html=True)
                    cache_analise, _ = checar_cache_analise(texto_analise)
                    if cache_analise:
                        resultado_final = cache_analise + "\n\n*(⚡ Resultado obtido do Cache)*"
                    else:
                        resultado_final = analisar_texto_ia(texto_analise, origem="streamlit", metadados=meta_web)

            status_box.empty() 
            
            if resultado_final:
                st.session_state['ultimo_resultado_ia'] = resultado_final
                st.session_state['dados_tecnicos_cache'] = dados_tecnicos_capturados
            
        except Exception as e:
            status_box.empty()
            st.error(f"Erro interno: {e}")
            registrar_log(f"Erro Frontend: {e}", "ERRO")
        
        st.session_state['processing'] = False
        st.rerun()

    if st.session_state['ultimo_resultado_ia']:
        txt_orig = st.session_state['texto_para_analisar']
        resumo = txt_orig[:60] + "..." if len(txt_orig) > 60 else txt_orig
        st.markdown(f"<div class='context-box'>Analisando: <b>{resumo}</b></div>", unsafe_allow_html=True)

        txt_ia = st.session_state['ultimo_resultado_ia']
        
        ver, score, css, icon = parse_ia(txt_ia)
        
        clean_txt = re.sub(r'.*Veredito:?.*\n?', '', txt_ia, flags=re.I)
        clean_txt = re.sub(r'.*(?:Score|Nível de Segurança).*\n?', '', clean_txt, flags=re.I)
        clean_txt = clean_txt.split("⚠️ REGRA VISUAL")[0].strip()

        st.markdown(f"""
        <div class="result-box">
            <div class="verdict-header">
                <div class="verdict-title {css}">{icon} {ver}</div>
                <div class="risk-score">Nível de Segurança: <b>{score}/100</b></div>
            </div>
            <div style="font-size: 16px; line-height: 1.6; color: var(--ios-text);">{clean_txt.replace(chr(10), '<br>')}</div>
        </div>""", unsafe_allow_html=True)

        # Narração (Acessibilidade)
        if st.session_state.get('narracao_ativa', False):
            texto_falado = f"Veredito: {ver}. Segurança: {score} de 100. " + re.sub(r'[*_#`:]', '', clean_txt)
            
            # Evita o "looping" quando a tela é recarregada pelo usuário interagindo com outros botões
            if st.session_state.get('ultimo_audio_falado') != texto_falado:
                try:
                    tts = gTTS(text=texto_falado, lang='pt', slow=False)
                    
                    # Usar NamedTemporaryFile para gerar o MP3 sem salvar permanentemente no servidor
                    with tempfile.NamedTemporaryFile(delete=False, suffix='.mp3') as t_file:
                        tts.save(t_file.name)
                        st.audio(t_file.name, format="audio/mpeg", autoplay=True)
                    
                    # Marca como já falado
                    st.session_state['ultimo_audio_falado'] = texto_falado
                except Exception as e:
                    st.error(f"Erro na narração: {e}")

        if st.session_state.get('dados_tecnicos_cache'):
            d = st.session_state['dados_tecnicos_cache']
            with st.expander("📊 Detalhes Técnicos", expanded=False):
                c1, c2 = st.columns(2)
                c1.metric("Idade", d.get("idade", "?"))
                ssl_info = d.get("ssl", "")
                c2.metric("SSL", "Válido" if "Emitido" in ssl_info else "Risco")
                
                scan_res = d.get('urlscan', '')
                if "MALICIOSO" in scan_res: st.error(f"URLScan: {scan_res}")
                
                typo = d.get("typosquatting")
                if typo != "Não": st.error(f"Clone de Marca: {typo}")

        if not st.session_state['feedback_enviado']:
            st.markdown("---")
            c1, c2 = st.columns(2)
            with c1: st.button("👍 Útil", use_container_width=True, on_click=processar_feedback_wrapper, args=("POSITIVO",), type="secondary")
            with c2: st.button("👎 Errado", use_container_width=True, on_click=processar_feedback_wrapper, args=("NEGATIVO",), type="secondary")
        else:
            st.caption("Feedback enviado. Obrigado!")

    st.markdown("<br>", unsafe_allow_html=True)
    
    # --- CONTROLES DE ACESSIBILIDADE VIA BOTAO NATIVO ---
    if 'show_acc_menu' not in st.session_state:
        st.session_state['show_acc_menu'] = False

    if st.button("♿", type="secondary", use_container_width=True):
        st.session_state['show_acc_menu'] = not st.session_state['show_acc_menu']

    if st.session_state['show_acc_menu']:
        # Container visual para parecer com os detalhes de um expander
        st.markdown(f"""
        <div style="border: 1px solid var(--ios-button); border-radius: 12px; padding: 15px; background-color: var(--ios-card); margin-bottom: 15px;">
            <h4 style="text-align: center; margin-top: 0; color: var(--ios-text);">Acessibilidade e Ajustes</h4>
            <p style="text-align: center; color: gray; font-size: 0.9em;">Opções para melhorar a leitura e interação.</p>
        </div>
        """, unsafe_allow_html=True)
        
        c1, c2 = st.columns(2)
        with c1:
            modo_contraste = st.toggle("Modo Alto Contraste", value=st.session_state['modo_alto_contraste'])
            if modo_contraste != st.session_state['modo_alto_contraste']:
                st.session_state['modo_alto_contraste'] = modo_contraste
                st.rerun()
                
        with c2:
            st.session_state['narracao_ativa'] = st.toggle("Narração por Voz (Áudio)", value=st.session_state['narracao_ativa'])
            
        st.caption("A narração tocará automaticamente ao término de cada análise para evitar a leitura tátil constante.")
        st.markdown("<br>", unsafe_allow_html=True)

    if st.button("📲 Instalar App", type="secondary", use_container_width=True):
        mostrar_instrucoes_instalacao()

    if is_browser_compatible():
        if st.button("🧩 Instalar Extensão", type="secondary", use_container_width=True):
            mostrar_instrucoes_extensao()
    
    if st.button("📜 Termos de Uso", type="secondary", use_container_width=True):
        mostrar_disclaimer()

    st.caption("Beta - Ajude a manter o serviço ativo: https://livepix.gg/asmaia")